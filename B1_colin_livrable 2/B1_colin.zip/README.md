# Mini projet en développement web (IUT)

L'objectif est de concevoir un site web basé sur l'acronyme CRUD (Create Read Update Delete), où on doit pouvoir ajouter, modifier et supprimer des régions, mais aussi ajouter, modifier et supprimer dans ces régions des clubs.