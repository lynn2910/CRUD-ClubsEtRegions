SECRET_KEY: str = '86t0{m1mnvDmDcv3*}gW7K@]4kmuu})YH@PBJo*TUP8)U@}XKKz@PjR%}nA4D}35'

HOST: str = '0.0.0.0'
PORT: int = 2550
